﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace KTG.Models
{
	public class Cities
	{
		[Key]
		public int CityID { get; set; }
		public string CityName { get; set; }
		public string State { get; set; }
		public virtual ICollection<Shul> Shuls { get; set; } = new HashSet<Shul>();
		public virtual ICollection<Activity> Activities { get; set; } = new HashSet<Activity>();
		public virtual ICollection<Hotel> Hotels { get; set; } = new HashSet<Hotel>();
		public virtual ICollection<FoodEstablishment> FoodEstablishments { get; set; } = new HashSet<FoodEstablishment>();
	}
}